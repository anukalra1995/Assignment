package com.QuesAns.Service.ServiceInterface;

import java.util.List;

import com.QuesAns.Dto.*;
import com.QuesAns.Model.*;

public interface QuestionService {
	
	public void save(Questions question, Category category);
	
	public List<Questions> findAllQuestions();
	
	public List<NextQuestionDto> getQuestions(int questionId, String answer);
	
	public List<QuestionsDto> getQuestionsDataList();
	
	public QuestionsDto getQuestionsData();
	
	public List<QuestionsDto> getQuestionData(int questionId);
}

package com.QuesAns.Service;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.QuesAns.Dto.*;
import com.QuesAns.Model.*;
import com.QuesAns.Repository.*;
import com.QuesAns.Service.ServiceInterface.QuestionService;

@Service
public class QuestionsServiceImpl implements QuestionService {

	@Autowired
	QuestionAnswerRepository quesRepo;
	
	@Autowired
	CategoryRepository categoryRepo;
		
	@Override
	public void save(Questions question, Category category) {
		
		try {
			categoryRepo.save(category);
			quesRepo.save(question);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public List<Questions> findAllQuestions() {
		List<Questions> quesAll = quesRepo.findAll();
		return quesAll;
	}

	@Override
	public List<NextQuestionDto> getQuestions(int questionId, String answer) {

		NextQuestionDto newQuestion = new NextQuestionDto();
		List<NextQuestionDto> abc = new ArrayList<>();	
		
		Questions QuesData = findAllQuestions().stream().filter(x -> x.getId() == questionId).findAny().get();
		Questions newListQues = findAllQuestions().stream().filter(x -> x.getId() != questionId).findAny().get();
		
		QuestionsDto newQues = new QuestionsDto(newListQues.getId(), newListQues.getQuestion());
		
		newQuestion.setNext_question(newQues);
		if(QuesData.getAnswer().equals(answer)) {
			newQuestion.setCorrect_answer(answer);
		} else {
			newQuestion.setCorrect_answer(QuesData.getAnswer());
		}
		abc.add(newQuestion);
		
		return abc;
	}
	
	@Override
	public QuestionsDto getQuestionsData() {
		
		QuestionsDto newQuestion = new QuestionsDto();
		findAllQuestions().stream().forEach((ques)->{
			newQuestion.setQuestion_id(ques.getId());
			newQuestion.setQuestion(ques.getQuestion());
//			abc.add(newQuestion);
		});
		return newQuestion;
	}
	

	@Override
	public List<QuestionsDto> getQuestionData(int questionId) {
		List<QuestionsDto> newQues = new ArrayList<>();
		QuestionsDto newQuestion = new QuestionsDto();
		
		findAllQuestions().stream().filter(ques -> ques.getId() == questionId).forEach((ques)->{
			newQuestion.setQuestion_id(ques.getId());
			newQuestion.setQuestion(ques.getQuestion());
			newQues.add(newQuestion);
		});
		return newQues;
	}

	
	@Override
	public List<QuestionsDto> getQuestionsDataList() {
		return null;
	}

	

}

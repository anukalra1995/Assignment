package com.QuesAns.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.QuesAns.Dto.*;
import com.QuesAns.Model.Questions;
import com.QuesAns.Service.ServiceInterface.QuestionService;

@RestController
public class QuesAnsController {
	
	@Autowired
	QuestionService quest;
	
	@GetMapping(value="/all")
	public List<Questions> getAllQuestions() {
		return quest.findAllQuestions();
	}
	
	@PostMapping(value = "/next")
	public List<NextQuestionDto> getNextQuestions(@RequestBody QuesAnswer ans) {
		return quest.getQuestions(ans.getQuestion_id(), ans.getAnswer());
		
	}
	
	@GetMapping(value="/plays")
	public List<QuestionsDto> getQuestionList() {
		return quest.getQuestionsDataList();
	}
	
	@GetMapping(value="/play")
	public QuestionsDto getQuestions() {
		return quest.getQuestionsData();
	}
}

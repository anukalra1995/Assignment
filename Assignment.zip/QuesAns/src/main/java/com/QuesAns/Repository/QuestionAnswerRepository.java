package com.QuesAns.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.QuesAns.Model.Questions;

public interface QuestionAnswerRepository extends JpaRepository<Questions, Long> {

}

package com.QuesAns;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.QuesAns.Model.*;
import com.QuesAns.Service.ServiceInterface.QuestionService;

@SpringBootApplication
public class QuesAnsApplication {

	@Autowired
	private QuestionService quesAns;
		
	public static void main(String[] args) {
		SpringApplication.run(QuesAnsApplication.class, args);
	}
	
	@Bean
	public void addQuestionsData() {
		
		List<Questions> quesData = new ArrayList<>();
		String uri = "http://jservice.io/api/random";
		RestTemplate rests = new RestTemplate();
		while(quesData.size() < 5) {
			Questions[] data = rests.getForObject(uri, Questions[].class);
			for(Questions a : data) {
				quesData.add(a);
				Category category = a.getCategory();				
				quesAns.save(a,category);
				
			}
		}
	}
}

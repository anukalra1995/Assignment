package com.QuesAns.Dto;

import javax.persistence.OneToOne;

public class NextQuestionDto {
	
	String correct_answer;
	
	@OneToOne
	QuestionsDto next_question;

	public NextQuestionDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NextQuestionDto(String correct_answer, QuestionsDto next_question) {
		super();
		this.correct_answer = correct_answer;
		this.next_question = next_question;
	}

	public String getCorrect_answer() {
		return correct_answer;
	}

	public void setCorrect_answer(String correct_answer) {
		this.correct_answer = correct_answer;
	}

	public QuestionsDto getNext_question() {
		return next_question;
	}

	public void setNext_question(QuestionsDto next_question) {
		this.next_question = next_question;
	}

	@Override
	public String toString() {
		return "NextQuestionDto [correct_answer=" + correct_answer + ", next_question=" + next_question + "]";
	}
	
	
}
